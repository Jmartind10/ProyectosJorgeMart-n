package ProyectoClash;

import java.nio.file.Path;
import java.nio.file.Paths;

import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.profiles.ProfileFile;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

public class S3Cliente {

    private static final String REGION = "us-east-1";
    private static final String BUCKET = "bucket.proyecto.clash";

    private final S3Client s3;

    public S3Cliente() {
        
    	ProfileCredentialsProvider credenciales = ProfileCredentialsProvider
    			.builder()
    			.profileFile(ProfileFile.builder()
    			.type(ProfileFile.Type.CREDENTIALS)
    			.content(Paths.get("aa.txt"))
    			.build()).build();
        this.s3 = S3Client.builder()
                .region(Region.of(REGION))
                .credentialsProvider(credenciales)
                .build();

        System.out.println("Conectados!!!");
    }

    public void subirArchivo(String rutaLocal, String claveS3) {
        Path path = Paths.get(rutaLocal);

        PutObjectRequest request = PutObjectRequest.builder()
                .bucket(BUCKET)
                .key(claveS3)
                .build();

        s3.putObject(request, RequestBody.fromFile(path));
        System.out.println("Archivo subido a S3 en '" + BUCKET + "' con key: " + claveS3);
    }

    public void cerrar() {
        s3.close();
    }
}
