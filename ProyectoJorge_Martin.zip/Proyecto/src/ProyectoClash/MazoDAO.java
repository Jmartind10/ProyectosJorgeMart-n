package ProyectoClash;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MazoDAO {

	// INSERT en tabla mazos
	public void crearMazo(Mazo m) throws SQLException {
		String sql = "INSERT INTO mazos (" + "id_usuario, nombre, descripcion, popularidad, "
				+ "id_carta1, id_carta2, id_carta3, id_carta4, " + "id_carta5, id_carta6, id_carta7, id_carta8"
				+ ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection con = ConexionBD.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setLong(1, m.getIdUsuario());
			ps.setString(2, m.getNombre());
			ps.setString(3, m.getDescripcion());
			ps.setInt(4, m.getPopularidad());

			Long[] cartas = m.getCartas();
			for (int i = 0; i < 8; i++) {
				if (cartas[i] != null) {
					ps.setLong(5 + i, cartas[i]);
				} else {
					ps.setNull(5 + i, Types.BIGINT);
				}
			}
			ps.executeUpdate();
		}
	}

	public void actualizarImagenMazo(long idMazo, String imagenKey) throws SQLException {
		String sql = "UPDATE mazos SET imagen_key_mazo = ? WHERE id_mazo = ?";
		try (Connection con = ConexionBD.obtenerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, imagenKey);
			ps.setLong(2, idMazo);
			ps.executeUpdate();
		}
	}

	// Listar mazos ordenados por popularidad y fecha
	public List<Mazo> listarMazos() throws SQLException {
		String sql = "SELECT * FROM mazos ORDER BY popularidad DESC, fecha_creacion DESC";
		List<Mazo> lista = new ArrayList<>();

		try (Connection con = ConexionBD.obtenerConexion();
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {

			while (rs.next()) {
				Mazo m = new Mazo();
				m.setIdMazo(rs.getLong("id_mazo"));
				m.setIdUsuario(rs.getLong("id_usuario"));
				m.setNombre(rs.getString("nombre"));
				m.setDescripcion(rs.getString("descripcion"));
				m.setPopularidad(rs.getInt("popularidad"));

				Long[] cartas = m.getCartas();
				for (int i = 0; i < 8; i++) {
					long valor = rs.getLong("id_carta" + (i + 1));
					if (!rs.wasNull()) {
						cartas[i] = valor;
					}
				}
				lista.add(m);
			}
		}
		return lista;
	}
}
