package ProyectoClash;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    // INSERT en tabla usuarios
    public void crearUsuario(Usuario u) throws SQLException {
        String sql = "INSERT INTO usuarios (nombre_usuario, email, password_hash) "
                   + "VALUES (?, ?, ?)";
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, u.getNombreUsuario());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getPasswordHash());
            ps.executeUpdate();
        }
    }

    // SELECT por nombre_usuario
    public Usuario buscarPorNombre(String nombreUsuario) throws SQLException {
        String sql = "SELECT id_usuario, nombre_usuario, email, password_hash "
                   + "FROM usuarios WHERE nombre_usuario = ?";
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombreUsuario);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Usuario u = new Usuario();
                u.setIdUsuario(rs.getLong("id_usuario"));
                u.setNombreUsuario(rs.getString("nombre_usuario"));
                u.setEmail(rs.getString("email"));
                u.setPasswordHash(rs.getString("password_hash"));
                return u;
            }
            return null;
        }
    }
}
