package ProyectoClash;

public class Mazo {

	private Long idMazo;
	private Long idUsuario;
	private String nombre;
	private String descripcion;
	private int popularidad;
	private Long[] cartas = new Long[8];
	private String imagenKeyMazo;

	public String getImagenKeyMazo() {
		return imagenKeyMazo;
	}

	public void setImagenKeyMazo(String imagenKeyMazo) {
		this.imagenKeyMazo = imagenKeyMazo;
	}

	public Long getIdMazo() {
		return idMazo;
	}

	public void setIdMazo(Long idMazo) {
		this.idMazo = idMazo;
	}

	public Long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getPopularidad() {
		return popularidad;
	}

	public void setPopularidad(int popularidad) {
		this.popularidad = popularidad;
	}

	public Long[] getCartas() {
		return cartas;
	}

	public void setCartaEnPosicion(int posicion, Long idCarta) {
		if (posicion >= 0 && posicion < 8) {
			cartas[posicion] = idCarta;
		}
	}
}
