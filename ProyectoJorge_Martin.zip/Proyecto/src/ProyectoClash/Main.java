package ProyectoClash;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

	private static final Scanner SC = new Scanner(System.in);

	public static void main(String[] args) {

		UsuarioDAO usuarioDAO = new UsuarioDAO();
		CartaDAO cartaDAO = new CartaDAO();
		MazoDAO mazoDAO = new MazoDAO();
		S3Cliente s3 = new S3Cliente();

		int opcion;
		do {
			mostrarMenu();
			opcion = leerEntero("Elige opción: ");
			try {
				switch (opcion) {
				case 1 -> crearUsuario(usuarioDAO);
				case 2 -> listarCartas(cartaDAO);
				case 3 -> crearMazo(mazoDAO, cartaDAO);
				case 4 -> listarMazos(mazoDAO, cartaDAO);
				case 5 -> subirImagenMazo(s3);
				case 0 -> System.out.println("Saliendo...");
				default -> System.out.println("Opción no válida");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} while (opcion != 0);

		s3.cerrar();
		SC.close();
	}

	private static void mostrarMenu() {
		System.out.println("====== Clash Deck Manager ======");
		System.out.println("1. Crear usuario");
		System.out.println("2. Listar cartas disponibles");
		System.out.println("3. Crear mazo (elegir 8 cartas por ID)");
		System.out.println("4. Listar mazos");
		System.out.println("5. Subir imagen de mazo a S3");
		System.out.println("0. Salir");
	}

	private static int leerEntero(String mensaje) {
		System.out.print(mensaje);
		while (!SC.hasNextInt()) {
			System.out.print("Introduce un número: ");
			SC.next();
		}
		int valor = SC.nextInt();
		SC.nextLine();
		return valor;
	}

	private static long leerLong(String mensaje) {
		System.out.print(mensaje);
		while (!SC.hasNextLong()) {
			System.out.print("Introduce un número: ");
			SC.next();
		}
		long valor = SC.nextLong();
		SC.nextLine();
		return valor;
	}

	private static void crearUsuario(UsuarioDAO dao) throws SQLException {
		Usuario u = new Usuario();
		System.out.print("Nombre de usuario: ");
		u.setNombreUsuario(SC.nextLine());
		System.out.print("Email: ");
		u.setEmail(SC.nextLine());
		System.out.print("Password (texto plano, luego lo hasheas si quieres): ");
		u.setPasswordHash(SC.nextLine());
		dao.crearUsuario(u);
		System.out.println("Usuario creado.");
	}

	private static void listarCartas(CartaDAO dao) throws SQLException {
		List<Carta> cartas = dao.listarCartas();
		System.out.println("=== Cartas disponibles ===");
		for (Carta c : cartas) {
			System.out.println("ID " + c.getIdCarta() + " - " + c.getNombre() + " (" + c.getRareza() + ", "
					+ c.getTipo() + ", elixir " + c.getCosteElixir() + ")");
		}
	}

	private static void crearMazo(MazoDAO mazoDAO, CartaDAO cartaDAO) throws SQLException {
		Mazo m = new Mazo();
		m.setIdUsuario(leerLong("ID usuario propietario: "));
		System.out.print("Nombre del mazo: ");
		m.setNombre(SC.nextLine());
		System.out.print("Descripción: ");
		m.setDescripcion(SC.nextLine());

		// Primero mostramos las cartas para que sepan qué ID es cada una
		listarCartas(cartaDAO);

		System.out.println("Introduce IDs de carta para el mazo.");
		System.out.println("Tienes 11 cartas disponibles en la BD (IDs del 1 al 11).");
		System.out.println("Pon 0 para dejar hueco vacío (mazo de menos de 8 cartas).");

		for (int i = 0; i < 8; i++) {
			long idCarta;
			do {
				idCarta = leerLong("ID carta [" + (i + 1) + "] (1-11, 0 vacío): ");
				if (idCarta != 0 && (idCarta < 1 || idCarta > 11)) {
					System.out.println("El ID debe estar entre 1 y 11 o ser 0.");
				}
			} while (idCarta != 0 && (idCarta < 1 || idCarta > 11));

			if (idCarta > 0) {
				m.setCartaEnPosicion(i, idCarta);
			}
		}

		mazoDAO.crearMazo(m);
		System.out.println("Mazo creado.");
	}

	private static void listarMazos(MazoDAO mazoDao, CartaDAO cartaDao) throws SQLException {
		List<Mazo> mazos = mazoDao.listarMazos();
		for (Mazo m : mazos) {
			System.out.println("Mazo " + m.getIdMazo() + " - " + m.getNombre() + " (usuario " + m.getIdUsuario() + ")");

			Long[] cartas = m.getCartas();
			System.out.println("  Cartas del mazo:");
			for (Long idCarta : cartas) {
				if (idCarta != null) {
					Carta c = cartaDao.obtenerCartaPorId(idCarta);
					if (c != null) {
						System.out.println("    - " + idCarta + " - " + c.getNombre());
					} else {
						System.out.println("    - " + idCarta + " (no encontrada en BD)");
					}
				}
			}
			System.out.println();
		}
	}

	private static void subirImagenMazo(S3Cliente s3) {
		System.out.print("Ruta local del archivo (imagen/video): ");
		String ruta = SC.nextLine();
		System.out.print("Key en S3 (por ejemplo mazos/mazo1.png): ");
		String key = SC.nextLine();
		s3.subirArchivo(ruta, key);
	}
}
