package ProyectoClash;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

	private static final String URL = "jdbc:mysql://clash-deckbd.cq9s8e6gmvkr.us-east-1.rds.amazonaws.com:3306/clashdeckdb";
	private static final String USER = "admin";
	private static final String PASS = "76131249f";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); // MySQL 8+
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection obtenerConexion() throws SQLException {
		return DriverManager.getConnection(URL, USER, PASS);
	}
}
