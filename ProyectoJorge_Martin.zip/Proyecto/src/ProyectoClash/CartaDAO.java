package ProyectoClash;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CartaDAO {

    // Lista todas las cartas que ya tienes metidas en la BD
    public List<Carta> listarCartas() throws SQLException {
        String sql = "SELECT id_carta, nombre, rareza, tipo, coste_elixir, imagen_key FROM cartas";
        List<Carta> lista = new ArrayList<>();

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Carta c = new Carta();
                c.setIdCarta(rs.getLong("id_carta"));
                c.setNombre(rs.getString("nombre"));
                c.setRareza(rs.getString("rareza"));
                c.setTipo(rs.getString("tipo"));
                c.setCosteElixir(rs.getInt("coste_elixir"));
                c.setImagenKey(rs.getString("imagen_key")); // puede ser null si no la usas
                lista.add(c);
            }
        }
        return lista;
    }

    // NUEVO: obtener una carta por su id
    public Carta obtenerCartaPorId(long idCarta) throws SQLException {
        String sql = "SELECT id_carta, nombre, rareza, tipo, coste_elixir, imagen_key " +
                     "FROM cartas WHERE id_carta = ?";
        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, idCarta);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Carta c = new Carta();
                    c.setIdCarta(rs.getLong("id_carta"));
                    c.setNombre(rs.getString("nombre"));
                    c.setRareza(rs.getString("rareza"));
                    c.setTipo(rs.getString("tipo"));
                    c.setCosteElixir(rs.getInt("coste_elixir"));
                    c.setImagenKey(rs.getString("imagen_key"));
                    return c;
                } else {
                    return null;
                }
            }
        }
    }
}
