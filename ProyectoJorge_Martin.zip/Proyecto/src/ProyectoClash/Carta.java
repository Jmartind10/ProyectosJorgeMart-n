package ProyectoClash;

public class Carta {

	private Long idCarta;
	private String nombre;
	private String rareza; // COMUN, RARA, EPICA, LEGENDARIA, CAMPEON
	private String tipo; // TROPA, HECHIZO, EDIFICIO
	private int costeElixir;
	private String imagenKey;

	public String getImagenKey() {
		return imagenKey;
	}

	public void setImagenKey(String imagenKey) {
		this.imagenKey = imagenKey;
	}

	public Long getIdCarta() {
		return idCarta;
	}

	public void setIdCarta(Long idCarta) {
		this.idCarta = idCarta;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRareza() {
		return rareza;
	}

	public void setRareza(String rareza) {
		this.rareza = rareza;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getCosteElixir() {
		return costeElixir;
	}

	public void setCosteElixir(int costeElixir) {
		this.costeElixir = costeElixir;
	}
}
