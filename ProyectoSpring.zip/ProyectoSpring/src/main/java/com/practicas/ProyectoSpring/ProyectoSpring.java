package com.practicas.ProyectoSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoSpring {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoSpring.class, args);
	}

}
