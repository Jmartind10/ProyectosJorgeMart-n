package com.practicas.ProyectoSpring.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SaludoController {

	@GetMapping("/saludo")

	public String saludo() {
		return "Hola esto funciona";
	}
	
	@GetMapping("/saludo/{nombre}")

	public String saludoConNombre(@PathVariable("nombre") String nombre) {
		return "Hola "+nombre;
	}

}
