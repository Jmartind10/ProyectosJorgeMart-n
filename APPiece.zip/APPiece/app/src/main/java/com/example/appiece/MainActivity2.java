package com.example.appiece;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;

public class MainActivity2 extends AppCompatActivity {

    TextView mensaje;
    ImageButton imgBoton;
    Button btnWeb, btnNext, btnBack;
    CheckBox bOcultar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        bOcultar = findViewById(R.id.bOcultar);
        mensaje = findViewById(R.id.mensaje); // TextView del mensaje
        imgBoton = findViewById(R.id.btnImagen);
        btnWeb = findViewById(R.id.btnWeb);
        btnNext = findViewById(R.id.btnNext2);
        btnBack = findViewById(R.id.btnBack2);


        String nombre = getIntent().getStringExtra("nombre");
        String personaje = getIntent().getStringExtra("personaje");

        mensaje.setText("Hola " + nombre + ", veo que has elegido ser \"" + personaje + "\". ¿Qué deseas hacer hoy?");


        imgBoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity2.this, "Soy Monkey D Luffy y voy a ser el Rey de los Piratas", Toast.LENGTH_LONG).show();
            }
        });


        btnWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://onepiece.fandom.com"));
                startActivity(intent);
            }
        });


        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity2.this, MainActivity3.class);
                // Pasar también nombre y personaje a la actividad 3 si quieres
                i.putExtra("nombre", nombre);
                i.putExtra("personaje", personaje);
                startActivity(i);
            }
        });


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
bOcultar.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if (bOcultar.isChecked()){
            imgBoton.setVisibility(View.VISIBLE);
        }
        if (!bOcultar.isChecked()){
            imgBoton.setVisibility(View.INVISIBLE);
        }
    }
});

    }
}
