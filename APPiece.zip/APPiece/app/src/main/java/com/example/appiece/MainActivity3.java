package com.example.appiece;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.*;
import android.app.AlertDialog;
import android.view.View;

public class MainActivity3 extends AppCompatActivity {

    Spinner spinner;
    TextView infoPersonaje;
    Button btnDialog, btnDialog2, btnBack;

    String[] tripulacion, frutas, arcos, barcos, recompensas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        spinner = findViewById(R.id.spinner3);
        infoPersonaje = findViewById(R.id.infoPersonaje);
        btnDialog = findViewById(R.id.btnDialog);
        btnDialog2 = findViewById(R.id.btnDialog2);
        btnBack = findViewById(R.id.btnBack3);


        tripulacion = getResources().getStringArray(R.array.tripulacion);
        frutas = getResources().getStringArray(R.array.frutas);
        arcos = getResources().getStringArray(R.array.arcos);
        barcos = getResources().getStringArray(R.array.barcos);
        recompensas = getResources().getStringArray(R.array.recompensas);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, tripulacion);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String info = "Nombre: " + tripulacion[position] +
                        "\nFruta: " + frutas[position] +
                        "\nArco: " + arcos[position] +
                        "\nBarco(s): " + barcos[position] +
                        "\nRecompensa: " + recompensas[position];
                infoPersonaje.setText(info);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        btnDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity3.this)
                        .setTitle("One Piece")
                        .setMessage("¿Listo para la aventura?")
                        .setPositiveButton("OK", null)
                        .show();
            }
        });


        btnDialog2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity3.this)
                        .setTitle("Volver al Barco")
                        .setMessage("¿Quieres regresar al Thousand Sunny?")
                        .setPositiveButton("Sí", (dialog, which) -> finish())
                        .setNegativeButton("No", null)
                        .show();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}

