package com.example.appiece;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.*;
import android.content.Intent;
import android.view.View;
import android.widget.CompoundButton;

public class MainActivity extends AppCompatActivity {

    ImageView imagen;
    EditText editNombre;
    RadioGroup radioGroup;
    TextView txtMensajes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        imagen = findViewById(R.id.imagen);
        editNombre = findViewById(R.id.editNombre);
        radioGroup = findViewById(R.id.radioGroup);
        txtMensajes = findViewById(R.id.txtMensajes);

        Button btn1 = findViewById(R.id.btn1); // Gear 5
        ToggleButton toggle = findViewById(R.id.toggle); // Haki
        CheckBox check = findViewById(R.id.checkNakama);
        RadioButton rbLuffy = findViewById(R.id.rbLuffy);
        RadioButton rbZoro = findViewById(R.id.rbZoro);
        RadioButton rbSanji = findViewById(R.id.rbSanji);

        imagen.setImageResource(R.drawable.luffy);
        imagen.setTag("normal");

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedId = radioGroup.getCheckedRadioButtonId();

                if (checkedId == R.id.rbZoro) {
                    txtMensajes.setText("Zoro no puede usar Gear 5");
                    Toast.makeText(MainActivity.this, "Zoro no puede usar Gear 5", Toast.LENGTH_SHORT).show();
                    return;
                } else if (checkedId == R.id.rbSanji) {
                    txtMensajes.setText("Sanji no puede usar Gear 5");
                    Toast.makeText(MainActivity.this, "Sanji no puede usar Gear 5", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (imagen.getTag() == null || imagen.getTag().equals("normal")) {
                    imagen.setImageResource(R.drawable.luffyg5);
                    imagen.setTag("g5");
                    txtMensajes.setText("¡Gear 5 activado!");
                } else {
                    imagen.setImageResource(R.drawable.luffy);
                    imagen.setTag("normal");
                    txtMensajes.setText("Luffy vuelve a la forma normal");
                }

                Toast.makeText(MainActivity.this, "¡Gear 5 activado!", Toast.LENGTH_SHORT).show();
            }
        });

        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int checkedId = radioGroup.getCheckedRadioButtonId();

                if (checkedId == R.id.rbZoro) {
                    if (isChecked) {
                        imagen.setImageResource(R.drawable.zoro_haki);
                        txtMensajes.setText("Zoro usa Haki en su espada");
                    } else {
                        imagen.setImageResource(R.drawable.zoro);
                        txtMensajes.setText("Zoro vuelve a la forma normal");
                    }
                    Toast.makeText(MainActivity.this, "Zoro usa Haki en su espada", Toast.LENGTH_SHORT).show();
                    return;
                } else if (checkedId == R.id.rbSanji) {
                    if (isChecked) {
                        txtMensajes.setText("Sanji solo tiene Haki de observación");
                        Toast.makeText(MainActivity.this, "Sanji solo tiene Haki de observación (sin imagen)", Toast.LENGTH_SHORT).show();
                    } else {
                        imagen.setImageResource(R.drawable.sanji);
                        txtMensajes.setText("Sanji vuelve a la forma normal");
                    }
                    return;
                } else {
                    if (isChecked) {
                        imagen.setImageResource(R.drawable.luffy_haky);
                        txtMensajes.setText("Luffy activa el Haki");
                    } else {
                        imagen.setImageResource(R.drawable.luffy);
                        txtMensajes.setText("Luffy vuelve a la forma normal");
                    }
                    Toast.makeText(MainActivity.this, "Luffy activa el Haki", Toast.LENGTH_SHORT).show();
                }
            }
        });

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check.isChecked()) {
                    txtMensajes.setText("¡Ahora eres un Mugiwara!");
                    Toast.makeText(MainActivity.this, "¡Ahora eres un Mugiwara!", Toast.LENGTH_SHORT).show();
                } else {
                    txtMensajes.setText("Has abandonado la tripulación");
                }
            }
        });

        rbLuffy.setOnClickListener(v -> {
            imagen.setImageResource(R.drawable.luffy);
            toggle.setChecked(false);
            txtMensajes.setText("Seleccionaste a Luffy");
        });

        rbZoro.setOnClickListener(v -> {
            imagen.setImageResource(R.drawable.zoro);
            toggle.setChecked(false);
            txtMensajes.setText("Seleccionaste a Zoro");
        });

        rbSanji.setOnClickListener(v -> {
            imagen.setImageResource(R.drawable.sanji);
            toggle.setChecked(false);
            txtMensajes.setText("Seleccionaste a Sanji");
        });

        findViewById(R.id.btnNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = editNombre.getText().toString().trim();
                if (nombre.isEmpty()) {
                    editNombre.setError("Introduce un nombre.");
                    return;
                }

                Intent i = new Intent(MainActivity.this, MainActivity2.class);
                i.putExtra("nombre", nombre);

                int checkedId = radioGroup.getCheckedRadioButtonId();
                String personaje = "Luffy";
                if (checkedId == R.id.rbZoro) personaje = "Zoro";
                if (checkedId == R.id.rbSanji) personaje = "Sanji";
                i.putExtra("personaje", personaje);

                startActivity(i);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_info) {
            Toast.makeText(this, "Has seleccionado el poneglyph de Información", Toast.LENGTH_SHORT).show();
            // Código para mostrar info adicional
            return true;
        } else if (id == R.id.action_exit) {
            Toast.makeText(this, "Salir seleccionado", Toast.LENGTH_SHORT).show();
            finish(); // Cierra la actividad
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}